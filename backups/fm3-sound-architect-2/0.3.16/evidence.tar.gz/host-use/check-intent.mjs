import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {inspectStructure} from '/workspace/scratch/7bb7161c8153/research/0316-host-runtime/skills/fm3-sound-architect-2/engine/skills/instructions/scripts/drive-collector/fm3-prototype.mjs';
import {scanRecords,readGrid} from '/workspace/scratch/7bb7161c8153/research/0316-host-runtime/skills/fm3-sound-architect-2/engine/skills/instructions/scripts/fm3-layout.mjs';
import {findParam,decodeValue} from '/workspace/scratch/7bb7161c8153/research/0316-host-runtime/skills/fm3-sound-architect-2/engine/skills/instructions/scripts/fm3-table-encoder.mjs';
import {finalSoundState} from '/workspace/scratch/7bb7161c8153/research/0316-host-runtime/skills/fm3-sound-architect-2/engine/skills/instructions/scripts/fm3-final-state.mjs';
const out='/workspace/scratch/7bb7161c8153/research/host-0316-use';
const source='/workspace/scratch/7bb7161c8153/research/0316-host-runtime/skills/fm3-sound-architect-2/engine/skills/instructions/examples/JB_RHYTHM_LEVEL_MINUS3_NewLook.syx';
const original=fs.readFileSync(source),syx=fs.readFileSync(out+'/PARALLEL_LIVE.syx');
const before=inspectStructure(original),after=inspectStructure(syx);
const bb=Buffer.from(before.raw.body),ab=Buffer.from(after.raw.body);
const br=scanRecords(bb),ar=scanRecords(ab),src=new Map(br.records.map(r=>[r.family,r])),dst=new Map(ar.records.map(r=>[r.family,r]));
const report=JSON.parse(fs.readFileSync(out+'/PARALLEL_LIVE.validation.json'));
const state=finalSoundState(syx,report.controls),base=finalSoundState(original,[]);
const checks=[];
const ok=(name,test,details)=>{assert.ok(test,name);checks.push({check:name,passed:true,...(details===undefined?{}:{details})});};
const sha=x=>createHash('sha256').update(x).digest('hex');
const rec=(body,r)=>body.subarray(r.header,r.header+r.size);
const word=(slug,ch,pid)=>{const r=dst.get(slug);return ab.readUInt16LE(r.start+2*(('ABCD'.indexOf(ch)*r.words)+pid));};
const parameter=(slug,ch,name)=>{const p=findParam(slug,name),raw=word(slug,ch,p.param);return {raw,value:decodeValue(p,raw)};};
try {
 ok('Preset name and selected Scene 1',state.name==='PARALLEL LIVE'&&ab[0]===0);
 for(const slug of ['amp','cab','drive','delay','reverb','out1','in1']){
  const a=rec(ab,dst.get(slug)),b=rec(bb,src.get(slug));
  ok(slug+' complete record byte-identical to JB NewLook',a.equals(b),{bytes:a.length,sourceSha256:sha(b),finalSha256:sha(a)});
 }
 ok('System tail byte-identical',ab.subarray(ar.tail).equals(bb.subarray(br.tail)));
 ok('All original scene names preserved',JSON.stringify(state.scenes.map(s=>s.name))===JSON.stringify(base.scenes.map(s=>s.name)));
 for(const s of state.scenes){
  const b=base.scenes[s.scene-1];
  for(const slug of ['amp','cab','drive','delay','reverb'])ok('Scene '+s.scene+' '+slug+' behavior preserved',JSON.stringify(s.blocks[slug])===JSON.stringify(b.blocks[slug]));
  ok('Scene '+s.scene+' Drive 2 channel/bypass',s.blocks.drive2.channel==='A'&&s.blocks.drive2.bypass===(s.scene!==1));
  ok('Scene '+s.scene+' Volume channel/bypass',s.blocks.volpan.channel===(s.scene===2?'B':'A')&&s.blocks.volpan.bypass===(s.scene>2));
  ok('Scene '+s.scene+' Mixer active',s.blocks.mixer.channel==='A'&&s.blocks.mixer.bypass===false);
 }
 for(const [slug,ch,param,requested,raw] of [['drive2','A','DRIVE',4,26214],['volpan','A','GAIN',6,39320],['volpan','B','GAIN',8,52427],['in1','A','THRESH',-60,26214]]){
  const value=parameter(slug,ch,param);
  ok(slug+' '+ch+' '+param+' requested value',value.raw===raw&&Math.abs(Number(value.value)-requested)<0.001,{requested,...value});
 }
 const d1=src.get('drive'),d2=dst.get('drive2');
 const diff=[];
 for(let ch=0;ch<4;ch++)for(let pid=0;pid<d1.words;pid++)if(bb.readUInt16LE(d1.start+2*(ch*d1.words+pid))!==ab.readUInt16LE(d2.start+2*(ch*d2.words+pid)))diff.push({channel:'ABCD'[ch],pid});
 ok('Drive 2 channel words copied from Drive 1 except requested A Drive',JSON.stringify(diff)===JSON.stringify([{channel:'A',pid:1}]),diff);
 for(const ch of 'ABCD'){
  ok('Volume '+ch+' stereo input preserved',String(parameter('volpan',ch,'INPUTSELECT').value).trim()==='STEREO');
  ok('Volume '+ch+' THRU bypass preserved',String(parameter('volpan',ch,'BYPASSMODE').value).trim()==='THRU');
  ok('Volume '+ch+' L/R pan preserved',word('volpan',ch,4)===0&&word('volpan',ch,5)===65534);
 }
 ok('Send and Return records absent',!dst.has('send')&&!dst.has('return'));
 const cells=readGrid(ab).filter(c=>c.id!==0),byPos=new Map(cells.map(c=>[c.row+':'+c.col,c]));
 const byId=new Map(ar.records.map(r=>[r.eid,r.family]));
 const direct=new Map(cells.map(c=>[c,[]]));
 for(const c of cells)for(let row=0;row<4;row++)if(c.mask&(1<<row)){
  const from=byPos.get(row+':'+(c.col-1));assert.ok(from,'No link from an empty cell');direct.get(from).push(c);
 }
 const nextBlocks=c=>direct.get(c).flatMap(n=>n.id>=1024?nextBlocks(n):[byId.get(n.id)]);
 const edges=cells.filter(c=>c.id<1024).flatMap(c=>nextBlocks(c).map(n=>byId.get(c.id)+' -> '+n)).sort();
 const expected=['in1 -> drive','drive -> drive2','drive2 -> amp','amp -> cab','cab -> delay','cab -> reverb','delay -> mixer','reverb -> mixer','mixer -> volpan','volpan -> out1'].sort();
 ok('Final graph exactly matches requested signal flow',JSON.stringify(edges)===JSON.stringify(expected),edges);
 ok('No Cab bypass path warning',state.gridWarnings.length===0);
 ok('Final report has the actual file hash',report.outputSha256===sha(syx));
 ok('Four artifact verifier passed',JSON.parse(fs.readFileSync(out+'/verify.json')).passed===true);
 const result={passed:true,scope:'Offline intent/readback and byte preservation checks; no hardware access',checksCount:checks.length,source,sourceSha256:sha(original),outputSha256:sha(syx),checks,cpu:report.cpu,limitations:['This preset was not imported into an FM3; STORE/reload, audio and actual CPU remain unmeasured.','53.7% is an incomplete effects-core estimate: Mixer is omitted, Drive 2 assumes Drive 1 cost, Amp/Delay core is not visible, bypass does not save CPU.','No combined-preset prediction error bound is established. Input/Volume scales are not newly measured physical scales.','Delay and Reverb mix settings remain from the serial source. Parallel summing may change dry balance and level; no audio normalization is claimed.','Volume Gain is a 0–10 control (retained LOG 20A taper), not a dB value.','Global Out 1 mode is outside the preset; stereo routing and Volume/Pan stereo state are verified in-file.']};
 fs.writeFileSync(out+'/intent-checks.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({passed:true,checks:checks.length,outputSha256:sha(syx),cpuEstimatePercent:report.cpu.maxPercent,cpuUnknown:report.cpu.scenes[0].unknown}));
} catch(e){fs.writeFileSync(out+'/intent-checks.json',JSON.stringify({passed:false,checks,error:e.stack},null,2)+'\n');throw e;}
