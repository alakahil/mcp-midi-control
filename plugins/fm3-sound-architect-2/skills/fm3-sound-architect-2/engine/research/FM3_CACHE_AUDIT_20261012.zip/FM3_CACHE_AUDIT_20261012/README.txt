FM3 SOUND ARCHITECT — FM3-EDITI VAHEMÄLU AUDIT
12.10.2026

TULEMUS
Kasutaja fail effectDefinitions_11_13p0.cache on täielikult loetud:
275 412 baiti, 45 kirjelduste jaotist, 2509 kirjet. Loetud andmetest
taastatud vahemälufail kattub algfailiga baithaaval. Lugeja lükkas tagasi
kaheksa vigast sisendit (kärbitud failid, lisabaidid, vale päis,
ebamõistlikud loendurid ja vigane UTF-8).

Filteri jaotis 24 sisaldab 37 kirjet. See jaotise number ei ole SYX-i
Filter 1 effectId, mis on meie mõõdetud presetis 114.
Kõigi 37 kirje arvuline metaandmestik ja kõigi 11 tekstivalikutega kirje
valikuloendid kattuvad kaasatud FM3 lähtekataloogiga. Float32 väärtusi
võrreldakse suhtelise tolerantsiga 1e-6 ja absoluutse tolerantsiga 1e-7.

FILTERI NÄITED
Frequency: 20–20 000 Hz
Q: 0,1–10
Gain: −20…+20 dB
Level: −80…+20 dB
Left Pan / Right Pan: −100…+100
Low Cut: 20–2000 Hz
High Cut: 200–20 000 Hz
Bypass Mode: THRU; MUTE FX OUT
Order (FILTER_ORDER): 2nd; 4th
All-Pass Order (FILTER_APORDER): eraldi kirje, vahemik 1–12
Phase Invert: NONE; RIGHT; LEFT; BOTH
Scene Ignore: OFF; ON
Bypass on eraldi parameeter ja FM3-Editi XML-is eraldi nupp.

Olemasolevad 17 Filteri kontrollpunkti valideeriti uuesti kohalike
SYX/GET tõendite ja kontrollsummade vastu: 17/17 läbisid kontrolli.
Vahemälust võetud piiridega annavad varasemad logaritmilise Frequency/Q
ning lineaarse Gain/Level teisenduse kandidaadid samad 17 raw-väärtust.
Need ei ole uued seadmemõõtmised ega kogu väärtusvahemiku valideerimine.
Vahemälu min/max ei tõenda iseenesest teisendusvalemit ega raw-skaalat.

VÕRDLUS VARASEMA LÄHTEKATALOOGIGA
1831 kirjet seostati kataloogiga; 1819 arvulise metaandmestiku vastet,
12 erinevust. 459 tekstivalikute loendit kattusid, 7 erinesid ja 62
puudusid lähtekataloogi enum-tabelist. 678 kirjet jäid selle kataloogiga
seostamata, sh erikirjed ja jaotised, millele polnud vastavat kaarti.
See ei tähenda, et kõik 2509 kirjet oleksid kasutajale nähtavad FX-juhid.

Võrdlus kasutab konkreetselt FM3_RANGES / FM3_ENUM_OVERRIDES tabeleid,
mitte samas bundle'is paiknevaid FM9 või Axe-Fx/AM4 tabeleid.
Vanema lähtekataloogi Amp/Chorus/Drive loendid on osaliselt aegunud.
Pluginas on aga ka uuemad eraldi mõõdetud mudelite teegid: näiteks
Chorus 27, Drive 87 ja Filter 18. Seetõttu ei tähenda erinevus vanema
kataloogiga automaatselt puuduolevat tuge pluginas.

KASUTAMINE ARENDUSES
Seda faili saab kasutada FW 13.0 metaandmete võrdlusallikana ning
kogujate küsimuste eeltäitmiseks koos FM3-Editi XML-i nähtavustingimustega.
Järgmine tehniline kontroll puudutab väärtuste teisendusi, tüübist
sõltuvaid juhtelemente ning alles seejärel uut genereeritud preseti
kontrollimporti ja tagasieksporti. Varem läbitud teste ei pea kordama
üksnes vahemälu lisandumise tõttu.

See pakett on eraldiseisev arendusaudit. Avaldatud plugin 0.71.0 ja
kohalik kandidaat 0.73.0 jäid muutmata. Uut kirjutusõigust, MIDI-liiklust,
uusi täisvahemiku lubadusi ega plugina avaldamist ei toimunud.
Serveri pluginaarhiivi failide arvu piirang on eraldi lahendamata küsimus.

FAILID JA KORDAMINE
effectDefinitions_11_13p0.cache — muutmata algfail.
fm3_cache_audit.py — Python 3.9+ lugeja, ainult standardteegid.
cache-decoded.json — jaotised, kirjed, asukohad ja toorväljad.
pinned-fm3-metadata.json — olemasolevast koodist eraldatud FM3 tabelid.
compare_catalog.py — metaandmete ja 17 punktiga võrdluse kordamine.
catalog-comparison.json — täielik võrdlus ja erinevused.
filter-audit.json — Filteri 37 kirjet ning 17 punkti tulemused.
filter-controls.json — olemasoleva mõõtmiste kataloogi koopia.
parser-validation.json — vigaste failide ja valemikandidaatide kontrollid.
existing-evidence-regression.json — olemasoleva kirjutaja tõendikontroll.
provenance.json — lähtefailide päritolu ja kontrollsummad.

Kordamiseks selle kausta sees:
python3 fm3_cache_audit.py effectDefinitions_11_13p0.cache --output cache-decoded.json
python3 compare_catalog.py

Olemasolevate SYX/GET tõendifailide uus täielik kontroll vajab lisaks
plugina 0.73.0 arenduskandidaadi algseid tõendifaile. Neid siia ei
dubleeritud. Paketi compare_catalog.py kordab aritmeetilist võrdlust
kaasatud 17-punktilise kataloogiga.

FORMAADI PIIRID
42-baidise päise, typecode'i, nelja float32 välja, tekstide ja lõputabelite
paigutus tuletati failist ning kontrolliti täieliku baithaaval taastamisega.
Vahemiku, kuvakordaja ja sammu tähendust toetab olemasolev FM3 kataloog.
Tundmatud päiseväljad, tail_flags_raw ja auxiliary_u32_raw jäeti tooreks.
Neid ei nimetata vaikimisi väärtusteks ega käsitleta uue kirjutustõendina.
