#!/usr/bin/env python3
"""Reproduce metadata comparisons; does not change plugin capability gates."""
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from fm3_cache_audit import decode


def main():
    root = Path(__file__).resolve().parent
    decoded = decode((root / 'effectDefinitions_11_13p0.cache').read_bytes())
    catalog = json.loads((root / 'pinned-fm3-metadata.json').read_text())
    families = {s['section_tag']: s['family'] for s in catalog['sections']}
    names = {(p['family'], p['paramId']): p for p in catalog['params']}
    counts = Counter()
    differences, missing, filter_records, per_section = [], [], [], []
    for section in decoded['sections']:
        family = families.get(section['section_tag'])
        section_counts = Counter()
        for p in section['records']:
            pid = p['param_id']
            identity = dict(section_tag=section['section_tag'], family=family, param_id=pid)
            r = catalog['ranges'].get(family, {}).get(str(pid))
            lo, hi, scale, step = p['numeric_fields']
            values = dict(typecode=p['typecode'], displayMin=lo * (scale or 1),
                          displayMax=hi * (scale or 1), scale=scale, step=step)
            if r is None:
                counts['unmapped_records'] += 1
                missing.append(identity)
                continue
            counts['mapped_records'] += 1
            diff = {k: dict(cache=v, pinned=r.get(k)) for k, v in values.items()
                    if r.get(k) is None or not math.isclose(v, r[k], rel_tol=1e-6, abs_tol=1e-7)}
            status = 'numeric_mismatch' if diff else 'numeric_match'
            counts[status] += 1
            section_counts[status] += 1
            if diff:
                differences.append(dict(**identity, numeric_differences=diff))
            if p['labels']:
                before = catalog['enums'].get(family, {}).get(str(pid))
                status = ('labels_missing_from_pinned' if before is None else
                          'labels_match' if before == p['labels'] else 'labels_differ')
                counts[status] += 1
                section_counts[status] += 1
                if status != 'labels_match':
                    differences.append(dict(**identity, label_status=status,
                                            cache_labels=p['labels'], pinned_labels=before))
            if family == 'FILTER':
                named = names.get((family, pid), {})
                filter_records.append(dict(**identity, name=named.get('name'),
                                           label=named.get('displayLabel'), offset=p['offset'],
                                           cache_metadata=values, labels=p['labels'],
                                           matches_pinned_numeric=not diff,
                                           tail_flags_raw=p['tail_flags_raw']))
        per_section.append(dict(section_tag=section['section_tag'], family=family,
                                record_count=len(section['records']), comparisons=dict(section_counts)))
    comparison = dict(source_sha256=decoded['source_sha256'], counts=dict(counts),
                      numeric_tolerance=dict(relative=1e-6, absolute=1e-7),
                      per_section=per_section, differences=differences,
                      unmapped_records=missing,
                      scope='Pinned upstream FM3 tables only. The plugin also has newer independently validated libraries. Differences here are not automatically plugin defects.')
    points = json.loads((root / 'filter-controls.json').read_text())['points']
    fmap = {p['param_id']: p['cache_metadata'] for p in filter_records}
    point_results = []
    for p in points:
        r = fmap[p['parameterId']]
        lo, hi, v = r['displayMin'], r['displayMax'], p['targetValue']
        logarithmic = p['parameterId'] in (1, 2)
        normalized = math.log(v / lo) / math.log(hi / lo) if logarithmic else (v - lo) / (hi - lo)
        candidate = math.floor(normalized * 65534 + 0.5)
        point_results.append(dict(index=p['index'], channel=p['channel'], type=p['type'],
                                  parameter_id=p['parameterId'], target=v,
                                  measured_raw=p['raw'], candidate_raw=candidate,
                                  matches=candidate == p['raw']))
    filter_report = dict(section_tag=24, preset_effect_id=114, records=filter_records,
                         existing_points=point_results,
                         caveats=[
                             'The cache section tag is not the preset effect ID.',
                             'Names are joined from the pinned FM3 catalog; cache records contain IDs and menu labels, not parameter names.',
                             'Minimum, maximum, display multiplier and step interpretations are corroborated by existing metadata; tail flags remain uninterpreted.',
                             'Log/linear choices and denominator 65534 come from prior measurement work, not from reading the cache.',
                             'A successful comparison at 17 prior points does not establish complete continuous-range correctness.',
                             'No new device writes, hardware measurements, plugin publication or writer capability expansion occurred.'
                         ])
    for name, value in [('cache-decoded.json', decoded), ('catalog-comparison.json', comparison),
                        ('filter-audit.json', filter_report)]:
        (root / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(cache=decoded['validation'], comparison=dict(counts),
                         filter_points_matched=sum(p['matches'] for p in point_results))))


if __name__ == '__main__':
    main()
