FM3 SOUND ARCHITECT — REA NATIIVKOODI AUDIT, 12.10.2026

TULEMUS
Uus FM3_REA_PARAMETER_PACKET.json läbis päritolukontrolli. See ja eelmine
väärtuse teisenduse väljund pärinevad samast FM3-Edit 1.07.17 arm64 failist.
Ghidra pseudokoodi kontrolliti kohaliku sama faili masinkoodi vastu.

Uuritud juhtimisahel teisendab kasutajaliidese väärtuse käsu väärtuseks ning
pakib 32-bitise ujukomaarvu bitid viieks 7-bitiseks baidiks. Pakkimisel
säilivad bitid: ujukomaarvu ei teisendata selles kohas 16-bitiseks
presetisõnaks. SysEx-paketi päise, identifikaatorite, väärtuse ja
kontrollsumma paigutus on native-audit.json failis dokumenteeritud.

See on juhtimissõnumi vorming. Presetifaili väärtusvormingu koguvahemiku
valideerimine on eraldi ülesanne. Täielikku teisendust seadme firmware'is
pole selle tööga tõendatud. Olemasolevad 17 mõõdetud Filteri kirjutuspunkti
säilitavad senise staatuse; uusi kirjutusvõimalusi ei lisatud.

KASU PLUGINALE
Varasem vahemäluaudit annab vahemikud, kuvakordajad ja valikuloendid.
Natiivkood kinnitab kuvakordaja kasutamist ühes sisestusrajas ning näitab,
miks kõiki juhtimissõnumeid ei saa käsitleda presetifaili raw-väärtustena.
Järgmise koguja küsimused saab metaandmetest eeltäita, arvestades
FM3-Editi XML-is tüübist/firmware'ist sõltuvaid nähtavustingimusi.
Järgmine arendusetapp on Filteri alles lahendamata vastenduste sihitud
kogumise ettevalmistus. Varem kinnitatud mõõtmised tuleb taaskasutada.
Selle koodiharu kohta pole praegu vaja uut Ghidra käsku.

FAILID
native-audit.json — täpsed leiud, aadressid, piirid ja järgmine arendusetapp.
evidence/ — muutmata kasutaja REA väljundid GZIP-kujul, pseudokood ning
kolme seotud funktsiooni kohalik disassemblatsioon. Rakendust ennast siin
paketis ei ole. JSON-i näidisväärtused on arvutusnäited, mitte seadme liiklus.
SHA256SUMS.json — kõigi ülejäänud pakifailide kontrollsummad.

OLEK
See on eraldiseisev arendusmaterjal. Avaldatud pluginat ja kohalikku
arenduskandidaati ei muudetud. FM3-ga ühendust ei loodud; uusi heli- ega
CPU-katseid ei tehtud. REA/Ghidra terminal-call märkus puudutab analüsaatori
voomudelit, mitte seadme töötõrget. Vahemälu varasema auditi pakett
FM3_CACHE_AUDIT_20261012.zip säilitab oma väärtuse ja on selle lisa alus.
