
void FUN_100237874(undefined1 *param_1,long param_2,uint *param_3)

{
  int iVar1;
  uint uVar2;
  byte *pbVar3;
  byte bVar4;
  byte bVar5;
  ulong uVar7;
  int iVar8;
  uint uVar9;
  byte *pbVar10;
  byte *local_60;
  ulong local_58;
  int iVar6;
  
  pbVar10 = (byte *)0x0;
  local_60 = (byte *)0x0;
  local_58 = 0;
  if ((param_2 != 0) && (param_3 != (uint *)0x0)) {
    iVar1 = (int)(param_3[5] << 3 | 6) / 7 + 0xf;
    FUN_1002fc3e4(&local_60,(long)iVar1,1);
    pbVar3 = local_60;
    uVar2 = *param_3;
    if (local_58 < 2) {
      FUN_1002fc3e4(&local_60,2,1);
    }
    if (local_60 != (byte *)0x0) {
      *local_60 = (byte)uVar2 & 0x7f;
      local_60[1] = (byte)(uVar2 >> 7) & 0x7f;
    }
    uVar2 = param_3[1];
    if (local_58 < 4) {
      FUN_1002fc3e4(&local_60,4,1);
    }
    if (local_60 != (byte *)0x0) {
      local_60[2] = (byte)uVar2 & 0x7f;
      local_60[3] = (byte)(uVar2 >> 7) & 0x7f;
    }
    uVar2 = param_3[2];
    if (local_58 < 6) {
      FUN_1002fc3e4(&local_60,6,1);
    }
    if (local_60 != (byte *)0x0) {
      local_60[4] = (byte)uVar2 & 0x7f;
      local_60[5] = (byte)(uVar2 >> 7) & 0x7f;
    }
    uVar2 = param_3[3];
    if (local_58 < 0xb) {
      FUN_1002fc3e4(&local_60,0xb,1);
    }
    if (local_60 != (byte *)0x0) {
      local_60[6] = (byte)uVar2 & 0x7f;
      local_60[7] = (byte)(uVar2 >> 7) & 0x7f;
      local_60[8] = (byte)(uVar2 >> 0xe) & 0x7f;
      local_60[9] = (byte)(uVar2 >> 0x15) & 0x7f;
      local_60[10] = (byte)(uVar2 >> 0x1c);
    }
    uVar2 = param_3[4];
    if (local_58 < 0xd) {
      FUN_1002fc3e4(&local_60,0xd,1);
    }
    if (local_60 != (byte *)0x0) {
      local_60[0xb] = (byte)uVar2 & 0x7f;
      local_60[0xc] = (byte)(uVar2 >> 7) & 0x7f;
    }
    uVar2 = param_3[5];
    if (local_58 < 0xf) {
      FUN_1002fc3e4(&local_60,0xf,1);
    }
    pbVar10 = local_60;
    if (local_60 != (byte *)0x0) {
      local_60[0xd] = (byte)uVar2 & 0x7f;
      local_60[0xe] = (byte)(uVar2 >> 7) & 0x7f;
    }
    uVar2 = param_3[5];
    if (uVar2 != 0) {
      if ((int)uVar2 < 1) {
        bVar4 = 0;
        uVar7 = 0;
      }
      else {
        uVar7 = 0;
        iVar8 = 0;
        iVar6 = 0;
        uVar9 = 1;
        do {
          bVar5 = (byte)iVar6;
          if (uVar9 == 8) {
            uVar9 = 1;
            iVar6 = 0;
          }
          else {
            bVar4 = *(byte *)((long)param_3 + (long)iVar8 + 0x18);
            bVar5 = bVar4 >> (ulong)(uVar9 & 0x1f) & 0x7f | bVar5;
            iVar6 = ((uint)bVar4 & (0x7f << (ulong)(uVar9 & 0x1f) ^ 0xffffffffU)) <<
                    (ulong)(7 - uVar9 & 0x1f);
            uVar9 = uVar9 + 1;
            iVar8 = iVar8 + 1;
          }
          bVar4 = (byte)iVar6;
          pbVar3[uVar7 + 0xf] = bVar5;
          uVar7 = uVar7 + 1;
        } while (iVar8 < (int)uVar2);
        uVar7 = uVar7 & 0xffffffff;
      }
      pbVar3[uVar7 + 0xf] = bVar4;
    }
    FUN_100239c18(param_2,1,pbVar3,iVar1,*param_1);
  }
  _free(pbVar10);
  return;
}

