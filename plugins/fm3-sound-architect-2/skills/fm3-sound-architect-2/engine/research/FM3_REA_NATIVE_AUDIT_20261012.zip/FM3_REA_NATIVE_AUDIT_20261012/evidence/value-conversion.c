
ulong FUN_10017f8f0(ulong param_1,long param_2)

{
  uint *puVar1;
  int iVar2;
  char cVar3;
  ushort uVar4;
  ushort uVar5;
  undefined2 uVar6;
  bool bVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  long *plVar11;
  long lVar12;
  long lVar13;
  long lVar14;
  long lVar15;
  ulong uVar16;
  ushort *puVar17;
  undefined8 uVar18;
  undefined4 uVar19;
  code *pcVar20;
  int iVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  int *piVar25;
  undefined4 uVar26;
  uint *puVar27;
  uint uVar28;
  float fVar29;
  float fVar30;
  ushort local_8c;
  ushort local_8a;
  undefined8 local_88;
  ushort local_80;
  ushort uStack_7e;
  undefined4 uStack_7c;
  float local_78 [2];
  
  if (param_2 == 0) {
    return param_1;
  }
  plVar11 = (long *)___dynamic_cast(param_2,&PTR_vtable_100de4b68,&PTR_vtable_100dc0db8,
                                    0xffffffffffffffff);
  if (plVar11 == (long *)0x0) {
    return 0;
  }
  _pthread_mutex_lock((pthread_mutex_t *)(plVar11 + 0x19));
  uVar19 = *(undefined4 *)((long)plVar11 + 0xbc);
  uVar8 = _pthread_mutex_unlock((pthread_mutex_t *)(plVar11 + 0x19));
  uVar16 = (ulong)uVar8;
  switch(uVar19) {
  case 2:
  case 4:
    local_88 = 0;
    cVar3 = *(char *)((long)plVar11 + 0x116);
    if (cVar3 == '\0') {
      uVar6 = 0;
    }
    else {
      uVar6 = (undefined2)plVar11[0x23];
    }
    iVar9 = *(int *)((long)plVar11 + 0x184);
    uVar4 = *(ushort *)(plVar11 + 0x21);
    local_8a = *(ushort *)((long)plVar11 + 0x10a);
    uVar8 = (uint)local_8a;
    local_8c = uVar4;
    lVar15 = ___dynamic_cast(plVar11,&PTR_vtable_100dc0db8,&PTR_vtable_100dc00f0,0x108);
    lVar12 = ___dynamic_cast(plVar11,&PTR_vtable_100dc0db8,&PTR_vtable_100dc0098,0xf0);
    lVar13 = ___dynamic_cast(plVar11,&PTR_vtable_100dc0db8,&PTR_vtable_100dc0278,0xf0);
    lVar14 = ___dynamic_cast(plVar11,&PTR_vtable_100dc0db8,&PTR_vtable_100dc01c0,0x128);
    if (lVar15 == 0) {
      if (lVar12 == 0) {
        if (lVar13 == 0) {
          local_88 = CONCAT44(local_88._4_4_,9);
          if (lVar14 == 0) {
            uVar8 = (**(code **)(*plVar11 + 0x38))(plVar11);
            fVar29 = (float)uVar8;
          }
          else {
            if (*(int *)(lVar14 + 0x310) == 0) {
              uVar8 = *(uint *)(lVar14 + 0x32c);
              iVar10 = 0;
              if (((-1 < (int)uVar8) && ((int)uVar8 < (int)*(uint *)(lVar14 + 0x324))) &&
                 (uVar8 < *(uint *)(lVar14 + 0x324))) {
                lVar15 = *(long *)(*(long *)(lVar14 + 0x318) + (ulong)uVar8 * 8);
                iVar10 = 0;
                if (lVar15 != 0) {
                  fVar29 = (float)*(int *)(lVar15 + 0x14);
                  goto LAB_10017fe70;
                }
              }
            }
            else {
              iVar10 = *(int *)(lVar14 + 0x338);
            }
            fVar29 = (float)iVar10;
          }
        }
        else {
          if (uVar4 == 0) {
            uVar22 = 0xffffffff;
          }
          else {
            uVar28 = (uint)uVar4;
            uVar22 = 0xffffffff;
            if ((uVar28 & 0xffc0) != 0x400) {
              if (uVar28 < 0x400) {
                uVar24 = 0;
                puVar27 = &DAT_100539360;
                do {
                  puVar1 = puVar27 + -1;
                  uVar23 = uVar24;
                  if (*puVar1 != uVar28) {
                    uVar23 = uVar22;
                  }
                  uVar24 = *puVar27;
                  puVar27 = puVar27 + 2;
                  uVar22 = uVar23;
                } while (uVar24 != 0xffffffff && *puVar1 != (uint)uVar4);
                if (0x3a < uVar23) {
                  uVar23 = 0;
                }
              }
              else {
                uVar23 = 6;
              }
              uVar22 = (&DAT_100da17c8)[(ulong)uVar23 * 0xc];
            }
          }
          uVar19 = 9;
          if (uVar8 != (uVar22 & 0xffff) || uVar22 == 0xffffffff) {
            uVar19 = 0x52;
          }
          local_88 = CONCAT44(local_88._4_4_,uVar19);
          if (*(long *)(lVar13 + 0x300) == 0) goto LAB_10017fe6c;
          (**(code **)(**(long **)(*(long *)(lVar13 + 0x300) + 0x1b0) + 0x10))(&local_80);
          iVar10 = (**(code **)(CONCAT44(uStack_7c,CONCAT22(uStack_7e,local_80)) + 0x30))(local_78);
          (**(code **)(CONCAT44(uStack_7c,CONCAT22(uStack_7e,local_80)) + 0x58))(local_78);
          fVar29 = 1.0;
          if (iVar10 == 0) {
            fVar29 = 0.0;
          }
        }
      }
      else {
        local_88 = 0x52;
        lVar15 = *(long *)(lVar12 + 0x370);
        fVar29 = 0.0;
        if (lVar15 != 0) {
          iVar10 = *(int *)(lVar12 + 0x308) - *(int *)(lVar12 + 0x304);
          if (0 < iVar10) {
            iVar21 = *(int *)(lVar15 + 0x38) - *(int *)(lVar12 + 0x304);
            if (*(char *)(lVar12 + 0x2d8) != '\0') {
              iVar21 = *(int *)(lVar12 + 0x308) - *(int *)(lVar15 + 0x3c);
            }
            fVar29 = (float)iVar21 / (float)iVar10;
          }
        }
      }
    }
    else {
      local_88 = 0x52;
      fVar29 = *(float *)(lVar15 + 0x3d0) - *(float *)(lVar15 + 0x3cc);
      if (fVar29 == 0.0) {
LAB_10017fe6c:
        fVar29 = 0.0;
      }
      else {
        fVar29 = (*(float *)(lVar15 + 0x3c0) - *(float *)(lVar15 + 0x3cc)) / fVar29;
      }
    }
LAB_10017fe70:
    if (iVar9 != -1) {
      local_88._0_4_ = iVar9;
    }
    local_88 = CONCAT44(fVar29,(int)local_88);
    if (cVar3 != '\0') {
      uVar16 = FUN_1000b0980((long *)(param_1 + 0x218),uVar6);
      return uVar16;
    }
    pcVar20 = *(code **)(*(long *)(param_1 + 0x218) + 0xa0);
    puVar17 = &local_8c;
    uVar18 = 1;
    goto LAB_10017fea4;
  default:
    goto switchD_10017f97c_caseD_3;
  case 5:
    local_80 = (ushort)(int)plVar11[0x21];
    uStack_7e = (ushort)((uint)(int)plVar11[0x21] >> 0x10);
    uStack_7c = 10;
    break;
  case 6:
    local_80 = *(ushort *)(plVar11 + 0x21);
    uStack_7e = *(ushort *)((long)plVar11 + 0x10a);
    if (local_80 < 0x400) {
      iVar9 = 0;
      piVar25 = &DAT_100539360;
      iVar10 = -1;
      do {
        puVar27 = (uint *)(piVar25 + -1);
        iVar21 = iVar9;
        if (*puVar27 != (uint)local_80) {
          iVar21 = iVar10;
        }
        iVar9 = *piVar25;
        piVar25 = piVar25 + 2;
        iVar10 = iVar21;
      } while (iVar9 != -1 && *puVar27 != (uint)local_80);
      uStack_7c = 0xc;
      uVar26 = 0xc;
      uVar19 = 10;
LAB_10017fbe8:
      if ((1L << ((ulong)uStack_7e & 0x3f) & 0x100004008U) == 0) {
        uVar19 = uVar26;
      }
      if (uStack_7e < 0x21) {
        uVar26 = uVar19;
      }
      if (iVar21 == 0x1f) {
        uStack_7c = uVar26;
      }
    }
    else {
      uStack_7c = 0xc;
    }
    break;
  case 7:
    local_80 = (ushort)(int)plVar11[0x21];
    uStack_7e = (ushort)((uint)(int)plVar11[0x21] >> 0x10);
    uStack_7c = 0xb;
    break;
  case 8:
    local_80 = *(ushort *)(plVar11 + 0x21);
    uStack_7e = *(ushort *)((long)plVar11 + 0x10a);
    if (local_80 < 0x400) {
      iVar9 = 0;
      piVar25 = &DAT_100539360;
      iVar10 = -1;
      do {
        puVar27 = (uint *)(piVar25 + -1);
        iVar21 = iVar9;
        if (*puVar27 != (uint)local_80) {
          iVar21 = iVar10;
        }
        iVar9 = *piVar25;
        piVar25 = piVar25 + 2;
        iVar10 = iVar21;
      } while (iVar9 != -1 && *puVar27 != (uint)local_80);
      uStack_7c = 0xd;
      uVar26 = 0xd;
      uVar19 = 0xb;
      goto LAB_10017fbe8;
    }
    uStack_7c = 0xd;
    break;
  case 9:
    local_80 = (ushort)(int)plVar11[0x21];
    uStack_7e = (ushort)((uint)(int)plVar11[0x21] >> 0x10);
    uStack_7c = 0xf;
    local_78[0] = 0.0;
    goto LAB_10017fd94;
  case 10:
    local_78[0] = 0.0;
    local_80 = 0;
    uStack_7e = 0;
    uStack_7c = 0;
    if (*(long **)(param_1 + 0x5f8) == (long *)0x0) {
      iVar9 = 0;
    }
    else {
      iVar9 = (**(code **)(**(long **)(param_1 + 0x5f8) + 0xe0))();
    }
    uVar4 = *(ushort *)(plVar11 + 0x21);
    if (uVar4 < 0x400) {
      iVar10 = 0;
      piVar25 = &DAT_100539360;
      iVar21 = -1;
      do {
        puVar27 = (uint *)(piVar25 + -1);
        iVar2 = iVar10;
        if (*puVar27 != (uint)uVar4) {
          iVar2 = iVar21;
        }
        iVar10 = *piVar25;
        piVar25 = piVar25 + 2;
        iVar21 = iVar2;
      } while (iVar10 != -1 && *puVar27 != (uint)uVar4);
      bVar7 = iVar2 == 0x22;
    }
    else {
      bVar7 = false;
    }
    uVar5 = *(ushort *)((long)plVar11 + 0x10a);
    fVar29 = (float)(**(code **)(*plVar11 + 0x50))(plVar11);
    if (bVar7 && (ushort)(uVar5 - 6) < 4) {
      uStack_7c = 0x52;
      local_80 = uVar4;
      uStack_7e = uVar5;
      local_78[0] = (fVar29 + 50.0) / 100.0;
    }
    else {
      lVar15 = (**(code **)(**(long **)(param_1 + 0x228) + 0x18))
                         (*(long **)(param_1 + 0x228),uVar4,uVar5);
      if (lVar15 != 0) {
        uVar8 = *(uint *)(lVar15 + 4) >> 4 & 0xf;
        if (uVar8 == 6) {
          if (iVar9 == 0) {
            fVar29 = (float)___exp10f(fVar29 / 20.0);
            goto LAB_10017fd80;
          }
        }
        else if (uVar8 == 5) {
          fVar30 = 1.0;
          if (fVar29 / 10.0 <= 1.0) {
            fVar30 = fVar29 / 10.0;
          }
          local_78[0] = 0.0;
          if (0.0 <= fVar30) {
            local_78[0] = fVar30;
          }
          uStack_7c = 0x52;
          local_80 = uVar4;
          uStack_7e = uVar5;
          goto LAB_10017fd94;
        }
        fVar30 = *(float *)(lVar15 + 0x10);
        if (fVar30 == 0.0) {
          fVar30 = 1.0;
        }
        fVar29 = fVar29 / fVar30;
      }
LAB_10017fd80:
      uStack_7c = 9;
      local_80 = uVar4;
      uStack_7e = uVar5;
      local_78[0] = fVar29;
    }
LAB_10017fd94:
    pcVar20 = *(code **)(*(long *)(param_1 + 0x218) + 0xa0);
    puVar17 = &local_80;
    uVar18 = 0;
    goto LAB_10017fea4;
  }
  local_78[0] = 0.0;
  pcVar20 = *(code **)(*(long *)(param_1 + 0x218) + 0xa0);
  puVar17 = &local_80;
  uVar18 = 1;
LAB_10017fea4:
  uVar16 = (*pcVar20)(param_1 + 0x218,puVar17,uVar18,0);
switchD_10017f97c_caseD_3:
  return uVar16;
}

